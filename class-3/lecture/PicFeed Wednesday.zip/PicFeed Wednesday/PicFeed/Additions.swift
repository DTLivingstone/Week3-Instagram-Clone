//
//  Additions.swift
//  PicFeed
//
//  Created by Michael Babiy on 2/4/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import UIKit

extension UIImage
{
    class func resize(image: UIImage, size: CGSize) -> UIImage
    {
        UIGraphicsBeginImageContext(size)
        image.drawInRect(CGRect(x: 0, y: 0, width: size.width, height: size.height))
        
        let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return resizedImage
    }
}

extension NSURL
{
    static func imageURL() -> NSURL
    {
        guard let documentsDirectories = NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first else { fatalError("Error getting Documents directories.") }
        return documentsDirectories.URLByAppendingPathComponent("image")
    }
}
