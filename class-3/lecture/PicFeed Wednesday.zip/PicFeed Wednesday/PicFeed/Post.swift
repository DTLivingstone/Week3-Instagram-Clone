//
//  Post.swift
//  PicFeed
//
//  Created by Michael Babiy on 2/8/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import UIKit

class Post
{
    let image: UIImage
    
    init(image: UIImage)
    {
        self.image = image
    }
}