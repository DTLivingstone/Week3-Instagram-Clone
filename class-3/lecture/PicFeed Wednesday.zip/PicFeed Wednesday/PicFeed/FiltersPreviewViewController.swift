//
//  FiltersPreviewViewController.swift
//  PicFeed
//
//  Created by Michael Babiy on 2/4/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import UIKit

class FiltersPreviewViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
}
