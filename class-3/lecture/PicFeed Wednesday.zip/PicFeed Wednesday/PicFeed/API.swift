//
//  API.swift
//  PicFeed
//
//  Created by Michael Babiy on 2/8/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import UIKit
import CloudKit

typealias APICompletion = (success: Bool) -> ()

class API
{
    
    static let shared = API()
    
    let container: CKContainer
    let database: CKDatabase
    
    private init()
    {
        self.container = CKContainer.defaultContainer()
        self.database = self.container.privateCloudDatabase
    }
    
    func POST(post: Post, completion: APICompletion)
    {
        do {
            if let record = try Post.recordWith(post) {
                self.database.saveRecord(record, completionHandler: { (record, error) -> Void in
                    if error == nil && record != nil {
                        print(record)
                        completion(success: true)
                    }
                })
            }
            
        } catch let error { print(error) }
    }
    
    func GET(completion: (posts: [Post]?) -> ())
    {
        let query = CKQuery(recordType: "Post", predicate: NSPredicate(value: true))
        self.database.performQuery(query, inZoneWithID: nil) { (records, error) -> Void in
            if let records = records {
                
                var posts = [Post]()
                
                for record in records {
                    guard let asset = record["image"] as? CKAsset else { return }
                    guard let path = asset.fileURL.path else { return }
                    guard let image = UIImage(contentsOfFile: path) else { return }
                    
                    // Append newely created post.
                    posts.append(Post(image: image))
                }
                
                // ... Need to update the UI on the main thread.
                NSOperationQueue.mainQueue().addOperationWithBlock({ () -> Void in
                    completion(posts: posts)
                })
            }
        }
    }
}