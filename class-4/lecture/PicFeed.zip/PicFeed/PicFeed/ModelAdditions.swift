//
//  ModelAdditions.swift
//  PicFeed
//
//  Created by Michael Babiy on 2/8/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import UIKit
import CloudKit

enum PostError: ErrorType
{
    case WritingImage
    case CreatingCKRecord
}

extension Post
{
    class func recordWith(post: Post) throws -> CKRecord?
    {   
        let imageURL = NSURL.imageURL()
        guard let data = UIImageJPEGRepresentation(post.image, 0.7) else { throw PostError.WritingImage }
        let saved = data.writeToURL(imageURL, atomically: true)
        
        if saved {
            let asset = CKAsset(fileURL: imageURL)
            let record = CKRecord(recordType: "Post")
            record.setObject(asset, forKey: "image")
            
            return record
            
        } else { throw PostError.CreatingCKRecord }
    }
}