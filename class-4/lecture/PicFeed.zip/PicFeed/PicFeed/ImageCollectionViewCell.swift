//
//  ImageCollectionViewCell.swift
//  PicFeed
//
//  Created by Michael Babiy on 2/8/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell, Identity
{
    
    @IBOutlet weak var imageView: UIImageView!
    
    var post: Post? {
        didSet {
            self.imageView.image = post?.image
        }
    }
    
    override func prepareForReuse()
    {
        super.prepareForReuse()
        self.imageView.image = nil
    }
}
