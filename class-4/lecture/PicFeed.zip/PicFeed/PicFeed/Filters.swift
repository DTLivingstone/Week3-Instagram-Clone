//
//  Filters.swift
//  PicFeed
//
//  Created by Michael Babiy on 2/4/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import UIKit

typealias FiltersCompletion = (theImage: UIImage?) -> ()

class Filters
{
    private class func filter(name: String,  image: UIImage, completion: FiltersCompletion)
    {
        NSOperationQueue().addOperationWithBlock { () -> Void in
            
            guard let filter = CIFilter(name: name) else { fatalError("Check spelling.") }
            filter.setValue(CIImage(image: image), forKey: kCIInputImageKey)
            
            // GPU Context
            let options = [kCIContextWorkingColorSpace : NSNull()]
            let EAGContext = EAGLContext(API: EAGLRenderingAPI.OpenGLES2)
            let GPUContext = CIContext(EAGLContext: EAGContext, options: options)
            
            // Get final Image using GPU Rendering
            guard let outputImage = filter.outputImage else { return }
            let CGImage = GPUContext.createCGImage(outputImage, fromRect: outputImage.extent)
            
            NSOperationQueue.mainQueue().addOperationWithBlock({ () -> Void in
                completion(theImage: UIImage(CGImage: CGImage))
            })
        }
    }
    
    static var original = UIImage()
    
    class func original(image: UIImage, completion: FiltersCompletion){
        
        completion(theImage: self.original)
        
    }
    
    class func vintage(image: UIImage, completion: FiltersCompletion)
    {
        self.filter("CIPhotoEffectTransfer", image: image, completion: completion)
    }
    
    class func bw(image: UIImage, completion: FiltersCompletion)
    {
        self.filter("CIPhotoEffectMono", image: image, completion: completion)
    }
    
    class func chrome(image: UIImage, completion: FiltersCompletion)
    {
        self.filter("CIPhotoEffectChrome", image: image, completion: completion)
    }
}














