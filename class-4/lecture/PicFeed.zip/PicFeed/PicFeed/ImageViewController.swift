//
//  ViewController.swift
//  PicFeed
//
//  Created by Michael Babiy on 2/3/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

import UIKit

class ImageViewController: UIViewController, FiltersPreviewViewControllerDelegate
{
    @IBOutlet weak var imageView: UIImageView!
    
    lazy var imagePicker = UIImagePickerController()
    
    var post = Post()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.setupAppearance()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    func setupAppearance()
    {
        self.imageView.layer.cornerRadius = 3.0
    }
    
    func prsentActionSheet()
    {
        let actionSheet = UIAlertController(title: "Source", message: "Please select the source type.", preferredStyle: .ActionSheet)
        let cameraSourceAction = UIAlertAction(title: "Camera", style: .Default) { (action) -> Void in
            self.presentImagePicker(.Camera)
        }
        
        let photosSourceAction = UIAlertAction(title: "Photos", style: .Default) { (action) -> Void in
            self.presentImagePicker(.PhotoLibrary)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: nil)
        
        actionSheet.addAction(cameraSourceAction)
        actionSheet.addAction(photosSourceAction)
        actionSheet.addAction(cancelAction)
        
        self.presentViewController(actionSheet, animated: true, completion: nil)
    }
    
    func presentImagePicker(sourceType: UIImagePickerControllerSourceType)
    {
        self.imagePicker.delegate = self
        self.imagePicker.sourceType = sourceType
        self.presentViewController(imagePicker, animated: true, completion: nil)
    }
    
    func image(image: UIImage, didFinishSavingWithError error: NSError?, contextInfo: UnsafePointer<Void>)
    {
        if error == nil {
            let alertController = UIAlertController(title: "Saved!", message: "Your image has been saved to your photos.", preferredStyle: .Alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
            presentViewController(alertController, animated: true, completion: nil)
        }
    }
    
    @IBAction func addImageButtonSelected(sender: UIBarButtonItem)
    {
        if UIImagePickerController.isSourceTypeAvailable(.Camera) {
            self.prsentActionSheet()
        } else {
            self.presentImagePicker(.PhotoLibrary)
        }
    }
    
    @IBAction func editButtonSelected(sender: UIBarButtonItem)
    {
        guard let image = self.imageView.image else { return }
        
        self.post = Post(image: image)
        self.performSegueWithIdentifier(FiltersPreviewViewController.id(), sender: nil)
        
        
    }
    
    @IBAction func saveButtonSelected(sender: UIBarButtonItem)
    {   
        guard let image = self.imageView.image else { return }
        
        self.post = Post(image: image)
        
        API.shared.POST(self.post) { (success) -> () in
            if success {
                UIImageWriteToSavedPhotosAlbum(self.imageView.image!, self, #selector(ImageViewController.image(_:didFinishSavingWithError:contextInfo:)), nil)
            }
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == FiltersPreviewViewController.id(){
            guard let filtersPreviewViewController = segue.destinationViewController as? FiltersPreviewViewController else { return }
            
            filtersPreviewViewController.delegate = self
            filtersPreviewViewController.post = self.post
            
        }
    }
    
    func didFinishPickingImage(success: Bool, image: UIImage?) {
        
        if success{
            guard let image = image else {return }
            self.imageView.image = image
        }
        else{
            
            print("Unsuccessful at retrieving image!!!")
        }
        
        self.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    
}

extension ImageViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate
{   
    // MARK: UIImagePickerControllerDelegate
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?)
    {
        // Keep original image reference.
        Filters.original = image
        
        // Set UIImageView's image.
        self.imageView.image = image
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController)
    {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
}

